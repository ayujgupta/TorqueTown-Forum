import "./index.css";

function Advertise() {
  return (
    <div id="advertise-aside">
      <img
        className="advertise-aside-image"
        loading="lazy"
        src="https://s2.loli.net/2024/10/26/Ap5QlMmx9U3XPtE.jpg"
        alt="AD"
      />
    </div>
  );
}

export default Advertise;
