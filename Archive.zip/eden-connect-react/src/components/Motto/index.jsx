import "./index.css";

function Motto() {
  return <div id="motto"></div>;
}

export default Motto;
